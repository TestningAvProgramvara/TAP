import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

// TODO 1. Skapa en main
// TODO 2. H�mta plugin
// TODO 3. Hitta s�kf�ltet i google
// TODO 4. S�k efter "Testautomatisering Stockholm"
// TODO 5. Hitta s�k knappen, klicka p� den
// TODO 6. Ta from resultatstats och skriv ut de
public class Program {
	// Skapa en variabel som h�ller webdriver
	static WebDriver driver;
	// Wait map
	static Wait<WebDriver> wait;
	
	
	
	public static void main(String[] args) throws InterruptedException{
		// St�lla in driver till att anv�nda Firefox
		driver = new FirefoxDriver();
		// �ppna google
		driver.get("http://www.google.com");
		// St�lla in webdriverwait med driver den ska anv�nda och antalet sekunder den ska v�nta
		wait = new WebDriverWait(driver, 3);
		// Hitta s�k f�ltet och skriv in "Testautomatisering Stockholm"
		driver.findElement(By.id("lst-ib")).sendKeys("Testautomatisering Stockholm");
		// Hitta s�k knappen, klicka p� den
		driver.findElement(By.id("_fZl")).click();
		// V�nta tills dess att elementet �r synligt
		WebElement resultat = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("resultStats")));
		// Ta fram resultatstats och skriv ut
		// driver.findElement(By.id("resultStats"));
		System.out.println(resultat.getText());
	}
}
