﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnitTestPres.Library;
using NUnit.Framework;

// TODO 1. Change class name from Class1 to GetValueTester
// TODO 2. Change class file name from Class1.cs to GetValueTester.cs
// TODO 3. Add reference UnitTestPres.Library TO unit test project
// TODO 4. Through NuGet, install NUnit to this project.
// TODO 5. Add using NUnit.Framework
// TODO 6. Install Nunit Adapter from Tools-Extensions and Updates
// TODO 7. Add [TestFixture] to class
// TODO 8. Add Testcase named Converter_From_Int_1_To_String1()
// TODO 9. Add [Test] to method

namespace UnitTestPres.Tester
{
    [TestFixture]
    public class GetValueTester
    {
        //    [Test]
        //    public void Converter_From_Int_1_To_String1()
        //    {
        //        //Arrange (Prepare test case with the attributes required)
        //        int input = 1;
        //        string expectedOutput = "1";

        //        // Act (Perform the test case and get the actualOutput)
        //        Converter converter = new Converter();
        //        string actualOutput = converter.convertIntToString(input);

        //        // Assert (Check for errors based on the expectedOutput and actualOutput)
        //        Assert.AreEqual(expectedOutput, actualOutput);
        //    }
        //}

        [Test]
        public void Convert_From_Int_To_String(
            [Values(8215905128598124,49214981238,595012941,1598932984,1239812985,129589214)] int input)
        {
            Converter converter = new Converter();
            string expectedOut = input.ToString();
            Assert.AreEqual(expectedOut, converter.convertIntToString(input));
        }
    }
}
