﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Description: Library: Convert int to string

// TODO 1. Change class name from Class1 to Converter
// TODO 2. Change filename from Class1.cs to Converter.cs

// TODO 3. Add method Convert(int input)

namespace UnitTestPres.Library
{
    public class Converter
    {
        public string convertIntToString(int input)
        {
            return input.ToString();
        }
    }
}
